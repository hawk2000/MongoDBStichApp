exports = function(changeEvent) {
    const twilio = context.services.get("twilio-sms-service");
    
    var access = changeEvent.fullDocument;
    
    var col = context.services.get("mongodb-atlas").db("surveillance_system").collection("friends");
    var doc = col.findOne({ name: access.name }).then(result => {
    if(!result) {
      twilio.send({
        to: "+XXXXXXXXXX",
        from: "+XXXXXXXXXX",
        body: "Hi Lord Commander of the Night's Watch " 
          + " - just to let you know that " + access.name  
          + " approached Invernalia limits. Send your men to fight!"
      });
    }
  });
};